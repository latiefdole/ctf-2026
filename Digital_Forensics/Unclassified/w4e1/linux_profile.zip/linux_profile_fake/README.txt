Profil kernel untuk analisis memory forensics.
Kernel: Linux 5.15.0-91-generic x86_64
Dihasilkan oleh: volatility3 framework

Gunakan profil ini dengan tool analisis memori yang mendukung format LiME.
