import os

# Konfigurasi API DevNusa
API_KEY = os.environ["API_KEY"]
API_ENDPOINT = os.environ.get("API_ENDPOINT", "https://api.devnusa.id/v1")
TIMEOUT = int(os.environ.get("TIMEOUT", "30"))
MAX_RETRIES = int(os.environ.get("MAX_RETRIES", "3"))
