# DevNusa API Client

Library klien Python untuk mengakses DevNusa API.

## Instalasi

```bash
pip install devnusa-client
```

## Penggunaan

```python
from devnusa import Client
client = Client()
data = client.get_data()
```

## Lisensi
MIT License - PT DevNusa Indonesia
