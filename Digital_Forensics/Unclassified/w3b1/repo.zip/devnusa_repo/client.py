import requests
from config import API_KEY, API_ENDPOINT, TIMEOUT

class DevNusaClient:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Bearer {API_KEY}',
            'Content-Type': 'application/json'
        })

    def get_data(self, endpoint):
        url = f"{API_ENDPOINT}/{endpoint}"
        resp = self.session.get(url, timeout=TIMEOUT)
        resp.raise_for_status()
        return resp.json()

    def post_data(self, endpoint, payload):
        url = f"{API_ENDPOINT}/{endpoint}"
        resp = self.session.post(url, json=payload, timeout=TIMEOUT)
        resp.raise_for_status()
        return resp.json()
